
import aiohttp
import pandas as pd

class DataFetcher:
    def __init__(self):
        self.base_url = "https://api.upbit.com/v1"

    async def fetch_candles(self, market, interval, count):
        url = f"{self.base_url}/candles/{interval}?market={market}&count={count}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                data = await response.json()
                df = pd.DataFrame(data)
                df['timestamp'] = pd.to_datetime(df['candle_date_time_utc'])
                return df

    async def fetch_all_timeframes(self, market):
        timeframes = [
            "minutes1", "minutes3", "minutes5", "minutes10", "minutes30",
            "minutes60", "days", "weeks", "months"
        ]
        all_data = {}
        for timeframe in timeframes:
            all_data[timeframe] = await self.fetch_candles(market, timeframe, count=200)
        return all_data
