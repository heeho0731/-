
import pandas as pd

class Backtester:
    def __init__(self, indicator_manager):
        self.indicator_manager = indicator_manager

    def run_backtest(self, df, combinations):
        results = []
        for combination in combinations:
            filtered_df = self.indicator_manager.apply_combination(df, combination)
            win_rate = self.calculate_win_rate(filtered_df)
            avg_profit = self.calculate_average_profit(filtered_df)
            results.append({
                "combination": combination,
                "win_rate": win_rate,
                "avg_profit": avg_profit
            })
        return pd.DataFrame(results)

    def calculate_win_rate(self, df):
        wins = df[df['result'] == 'Win']
        return len(wins) / len(df) if len(df) > 0 else 0

    def calculate_average_profit(self, df):
        return df['profit_loss'].mean() if 'profit_loss' in df else 0
