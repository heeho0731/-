
class TradeReporter:
    def send_email_report(self, trade_details, performance_metrics):
        subject = f"Trade Report: {trade_details['ticker']}"
        body = f"""
        Trade Summary:
        =====================
        Entry Price: {trade_details['entry_price']}
        Exit Price: {trade_details['exit_price']}
        Profit: {trade_details['profit']}

        Performance Metrics:
        =====================
        Win Rate: {performance_metrics['win_rate']}
        Average Profit: {performance_metrics['avg_profit']}
        """
        print("Email sent:", subject)
