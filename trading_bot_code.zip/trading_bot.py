
import asyncio
from data_fetcher import DataFetcher
from indicator_manager import IndicatorManager
from backtester import Backtester
from adaptive_ai import AdaptiveAI
from trade_reporter import TradeReporter

class TradingBot:
    def __init__(self):
        self.data_fetcher = DataFetcher()
        self.indicator_manager = IndicatorManager()
        self.backtester = Backtester(self.indicator_manager)
        self.ai = AdaptiveAI("model.h5", "scaler.pkl")
        self.reporter = TradeReporter()

    async def run(self, market):
        data = await self.data_fetcher.fetch_all_timeframes(market)
        combinations = self.indicator_manager.generate_combinations()
        results = self.backtester.run_backtest(data['minutes1'], combinations)
        trade_decision = self.ai.predict(data['minutes1'])
        self.reporter.send_email_report(trade_decision, results)
