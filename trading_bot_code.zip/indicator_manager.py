
from itertools import product

class IndicatorManager:
    def __init__(self):
        self.indicators = {
            "RSI": {"function": self.calculate_rsi, "params": {"period": [14]}},
            "MACD": {"function": self.calculate_macd, "params": {"short_period": [12], "long_period": [26], "signal_period": [9]}},
            "ATR": {"function": self.calculate_atr, "params": {"period": [14]}}
        }
        self.failed_combinations = set()

    def calculate_rsi(self, df, period):
        delta = df['close'].diff()
        gain = delta.where(delta > 0, 0).rolling(window=period).mean()
        loss = -delta.where(delta < 0, 0).rolling(window=period).mean()
        rs = gain / loss
        df[f'RSI_{period}'] = 100 - (100 / (1 + rs))
        return df

    def calculate_macd(self, df, short_period, long_period, signal_period):
        df[f'EMA_{short_period}'] = df['close'].ewm(span=short_period, adjust=False).mean()
        df[f'EMA_{long_period}'] = df['close'].ewm(span=long_period, adjust=False).mean()
        df[f'MACD_{short_period}_{long_period}'] = df[f'EMA_{short_period}'] - df[f'EMA_{long_period}']
        df[f'Signal_{signal_period}'] = df[f'MACD_{short_period}_{long_period}'].ewm(span=signal_period, adjust=False).mean()
        return df

    def calculate_atr(self, df, period):
        df['TR'] = df[['high', 'low', 'close']].apply(
            lambda row: max(row['high'] - row['low'], abs(row['high'] - row['close']), abs(row['low'] - row['close'])), axis=1
        )
        df[f'ATR_{period}'] = df['TR'].rolling(window=period).mean()
        return df

    def generate_combinations(self):
        combinations = []
        for name, indicator in self.indicators.items():
            params = indicator['params']
            param_keys = params.keys()
            param_values = product(*params.values())
            for param_set in param_values:
                combination = {name: dict(zip(param_keys, param_set))}
                combinations.append(combination)
        return combinations

    def apply_combination(self, df, combination):
        for name, params in combination.items():
            if name in self.indicators:
                function = self.indicators[name]["function"]
                df = function(df, **params)
        return df
