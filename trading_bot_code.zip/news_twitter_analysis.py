
import requests
from textblob import TextBlob

class MarketSentimentFetcher:
    def __init__(self):
        self.news_api_url = "https://newsapi.org/v2/everything"
        self.twitter_api_url = "https://api.twitter.com/2/tweets/search/recent"
        self.news_api_key = "your_news_api_key"
        self.twitter_bearer_token = "your_twitter_bearer_token"

    def fetch_news_sentiment(self, query, max_results=10):
        params = {"q": query, "apiKey": self.news_api_key, "pageSize": max_results}
        response = requests.get(self.news_api_url, params=params)
        articles = response.json().get("articles", [])
        sentiment_score = 0
        for article in articles:
            sentiment = TextBlob(article["title"]).sentiment.polarity
            sentiment_score += sentiment
        return sentiment_score / len(articles) if articles else 0

    def fetch_twitter_sentiment(self, query, max_results=10):
        headers = {"Authorization": f"Bearer {self.twitter_bearer_token}"}
        params = {"query": query, "max_results": max_results}
        response = requests.get(self.twitter_api_url, headers=headers, params=params)
        tweets = response.json().get("data", [])
        sentiment_score = 0
        for tweet in tweets:
            sentiment = TextBlob(tweet["text"]).sentiment.polarity
            sentiment_score += sentiment
        return sentiment_score / len(tweets) if tweets else 0

    def get_market_sentiment(self, query):
        news_sentiment = self.fetch_news_sentiment(query)
        twitter_sentiment = self.fetch_twitter_sentiment(query)
        return (news_sentiment + twitter_sentiment) / 2
