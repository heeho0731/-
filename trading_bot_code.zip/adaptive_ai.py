
from keras.models import load_model
import joblib

class AdaptiveAI:
    def __init__(self, model_path, scaler_path):
        self.model = load_model(model_path)
        self.scaler = joblib.load(scaler_path)

    def predict(self, df):
        features = df[['RSI_14', 'MACD_12_26', 'ATR_14']].values
        scaled_features = self.scaler.transform(features[-60:])
        X = scaled_features.reshape(1, 60, scaled_features.shape[1])
        return self.model.predict(X)[0, 0]

    def retrain(self, df):
        pass
